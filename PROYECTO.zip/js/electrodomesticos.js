//El consumo está puesto en w/h(watios)

export const datosElectrodomesticos = [
  {
    electrodomestico: "estufa",
    consumo: 1000,
  },
  {
    electrodomestico: "nevera",
    consumo: 150,
  },
  {
    electrodomestico: "congelador",
    consumo: 195,
  },
  {
    electrodomestico: "vitroceramica",
    consumo: 1200,
  },
  {
    electrodomestico: "pc",
    consumo: 300,
  },
  {
    electrodomestico: "tv",
    consumo: 140,
  },
  {
    electrodomestico: "lavadora",
    consumo: 520,
  },
  {
    electrodomestico: "microondas",
    consumo: 800,
  },
  {
    electrodomestico: "lavavajillas",
    consumo: 180,
  },
  {
    electrodomestico: "horno",
    consumo: 1300,
  },
  {
    electrodomestico: "secadora",
    consumo: 240,
  },
];
